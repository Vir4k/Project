const Discord = require('discord.js')
const bot = require('../config.json');
const emoji = require('../emoji.json');
const fs = require("fs");
const chalk = require("chalk");

module.exports.run = async (bot, message, args) => {
  
}

module.exports.config = {
    name: 'shop',
    description: 'Shows you the Shop',
    usage: `${bot.prefix}shop`,
    accessableby: 'Members',
    aliases: ['store']
}